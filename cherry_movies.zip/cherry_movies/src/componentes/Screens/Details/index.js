import { View,Text,Image } from "react-native"
import { useRoute } from "@react-navigation/native"


export default function Detalhes(){
   
   const route= useRoute();

    return(
            
        <View>
            <Image style={{width:350, height:450, marginLeft:50, marginTop:30}} source={{uri:route.params.img}} />
            <Text>{route.params.titulo}</Text>
            <Text>{route.params.nota}</Text>
            <Text>{route.params.sinopse}</Text>
        
        </View>
    )

}