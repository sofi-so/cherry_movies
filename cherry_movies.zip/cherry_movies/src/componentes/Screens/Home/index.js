import React from "react";
import {View, Text, TouchableOpacity, Image, StyleSheet,FlatList} from 'react-native'
import {Feather} from '@expo/vector-icons';
import CardMovies from "../../cardMovies"
import BannerFilmes from "../../bannerFilmes"
import Header from "../../header"
import Searchbar from "../../searchbar"
import movies from "../../../../movies/filmes"

 export default function Home(){
    return(
      <View style ={styles.container}>
        <Header></Header>
        <Searchbar></Searchbar>
        <BannerFilmes></BannerFilmes>
 
        <View style = {{width:'90%'}}>
          <FlatList
          data ={movies}
          horizontal={true}
          keyExtractor={(item) => item.id}
 
          renderItem={({item}) =>(
            <CardMovies titulo ={item.nome} img ={item.img} nota ={item.nota} sinopse={item.sinopse}> </CardMovies>
          )}
          />
 
        </View>
 
      </View>
      
    );
  }
 
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#141a29',
      alignItems: "center"
    }
  })
 